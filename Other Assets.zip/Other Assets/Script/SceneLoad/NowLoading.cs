﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NowLoading : MonoBehaviour {
	///Serialize:データ構造やオブジェクトの状態を、保存・再構築できるようなフォーマットに変換する
	///[](属性)を付けてSerialize可能な領域にしている
	[SerializeField]
	Animator animator;
	/// シングルトンでアクセスするための変数
	public static NowLoading Instance { set; get; }


	// Use this for initialization
	void Awake () {
		Instance = GetComponent<NowLoading> ();
		DontDestroyOnLoad(gameObject);
	}

	public void Cutin()	{
		animator.SetTrigger("Finish");
		//LoadingPanel.Instance.Finish ();
	}

	public void Cutout() {
		animator.SetTrigger("Start");
		//LoadingPanel.Instance.Start ();
	}

}
