﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using System.Collections;

[RequireComponent(typeof(Button))]
public class PlayingLoad : MonoBehaviour
{
    //他スクリプト参照
    Fade fade;

	// Use this for initialization
	void Start () {
        fade = GameObject.Find("Black Screen").GetComponent<Fade>();
		GetComponent<Button> ().onClick.AddListener (OnClick);
        fade.Cutout();
    }

    // Update is called once per frame
    void Update () {
	
	}

    //Click made it New Ivent
    void OnClick(){
        fade.Cutin();
        Invoke("Move", 2f);
	}

    void Move() {
        SceneManager.LoadScene("Playing Scene");
    }
}
