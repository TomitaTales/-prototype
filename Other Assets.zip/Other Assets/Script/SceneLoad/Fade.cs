﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fade : MonoBehaviour
{
    //
    Animator animator;
    //
    public StageTime stage;

    // Start is called before the first frame update
    void Start()
    {
        if (stage == null) {
            stage = null;
        }

        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Cutin()
    {
        animator.SetTrigger("Finish");
        //LoadingPanel.Instance.Finish ();
    }

    public void Cutout()
    {
        animator.SetTrigger("Start");
        //LoadingPanel.Instance.Start ();
    }

    public void Ready()
    {
        if (stage != null)
        {
            //最初のロード時のみ実行
            stage.setup = true;
        }
    }

}
