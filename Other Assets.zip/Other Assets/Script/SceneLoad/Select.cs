﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(Button))]

public class Select : MonoBehaviour
{
    //他スクリプト参照
    StageTime stage;
    Fade fade;

    // Start is called before the first frame update
    void Start()
    {
        stage = GameObject.Find("Canvas").GetComponent<StageTime>();
        fade = GameObject.Find("Black Screen").GetComponent<Fade>();
        GetComponent<Button>().onClick.AddListener(OnClick);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnClick()
    {
        switch (transform.name)
        {
            case "restart.Button":
                stage.ReStart();
                break;
            case "quit.Button":
                fade.Cutin();
                Invoke("Exit", 2f);
                break;
        }
    }


    public void Exit() {
        SceneManager.LoadScene("Start Scene");
    }


}
