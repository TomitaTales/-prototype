﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class StageTime : MonoBehaviour
{
    //カーテン
    private RectTransform rect;
    float under;
    //
    public Text cue;
    //開始と終了
    public bool setup;
    bool setdown;
    //
    Timer timer;
    public bool prefab;
    //
    PointSystem pointsystem;
    //
    GameObject player;
    //結果モード
    public GameObject result;
    //選択ボタン
    public Button reset;
    public Button quit;
    //
    Amidakuzi amidakuzi;
    Fade fade;


    // Start is called before the first frame update
    void Start()
    {
        //
        amidakuzi = GameObject.Find("Roads").GetComponent<Amidakuzi>();
        //フェードアウト
        fade = GameObject.Find("Black Screen").GetComponent<Fade>();
        fade.Cutout();
        //カーテンの初期設定
        rect = GameObject.Find("Carten").GetComponent<RectTransform>();
        under = rect.sizeDelta.y;
        //Textの初期設定
        cue.rectTransform.localPosition = new Vector3(0, -600, 0);
        cue.text = "Ready?";
        //開始と終了の初期設定
        setup = false;
        setdown = false;
        //プレハブは未開放
        prefab = false;
        //結果モード非表示
        result.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        timer = GameObject.Find("Main Camera").GetComponent<Timer>();
        pointsystem = GameObject.Find("Main Camera").GetComponent<PointSystem>();
        //蜘蛛を最低一匹探す
        player = GameObject.FindGameObjectWithTag("Player");
        ///Fadeが終わればcueを移動
        //ゲーム開始処理
        if (setup)
        {
            //スライドイン実行
            TextBegin();
        }
        //終了条件解放
        if (player != null)
        {
            setdown = true;
        }
        //ゲーム終了処理
        if (setdown)
        {
            //蜘蛛が一匹もいなくなったら実行
            if (player == null)
            {
                CartenDown();
                TextEnd();
            }
        }

        if (pointsystem.push)
        {
            reset.gameObject.SetActive(true);
            quit.gameObject.SetActive(true);
        }
    }


    void TextBegin()
    {
        //指定位置で停止
        if (cue.rectTransform.localPosition.y >= 0)
        {
            cue.rectTransform.localPosition = new Vector3(0, 0, 0);
            StartCoroutine("Gone");
        }
        //指定位置までスライドイン
        else
        {
            cue.rectTransform.localPosition += new Vector3(0, 50, 0);
        }
    }

    IEnumerator Gone() {
        //2秒後にText内容を変換
        yield return new WaitForSeconds(2f);
        cue.text = "Go!!";
        //幕上げ & タイム起動
        timer.once = true;
        CartenUp();
        //
        amidakuzi.stay = true;
        yield return new WaitForSeconds(2f);
        //重複阻止
        setup = false;
        //スライドアウト実行
        TextBegin2();
    }

    void TextBegin2() {
        //指定位置で停止
        if (cue.rectTransform.localPosition.y >= 600)
        {
            cue.rectTransform.localPosition = new Vector3(0, 600, 0);
         }
        //指定位置までスライドアウト
        else
        {
            cue.rectTransform.localPosition += new Vector3(0, 50, 0);
        }
    }

    void CartenUp() {
        //幕上げ終了
        if (rect.sizeDelta.y <= 0)
        {
            rect.sizeDelta = new Vector2(rect.sizeDelta.x, 0);
            //プレハブ生成開始
            prefab = true;
        }
        //幕上げ
        else {
            rect.sizeDelta -= new Vector2(0, 10);
        }
    }

    void TextEnd()
    {
        //指定位置で停止
        if (cue.rectTransform.localPosition.y <= 0)
        {
            cue.rectTransform.localPosition = new Vector3(0, 0, 0);
            StartCoroutine("Leave");
        }
        //指定位置までスライドイン
        else
        {
            //スライドイン前にText内容を変換
            cue.text = "Finish!";
            cue.rectTransform.localPosition -= new Vector3(0, 50, 0);
        }
    }

    IEnumerator Leave()
    {
        //幕閉じ & タイムストップ
        timer.once = false;
        CartenDown();
        amidakuzi.stay = false;
        //2秒後にスライドアウト
        yield return new WaitForSeconds(2f);
        //重複阻止
        setdown = false;
        //スライドアウト実行
        TextEnd2();
    }

    void TextEnd2()
    {
        //指定位置で停止
        if (cue.rectTransform.localPosition.y <= -600)
        {
            cue.rectTransform.localPosition = new Vector3(0, -600, 0);
            //結果表示モードへ
        }
        //指定位置までスライドアウト
        else
        {
            cue.rectTransform.localPosition -= new Vector3(0, 50, 0);
        }
    }

    void CartenDown()
    {
        //幕閉じ終了
        if (rect.sizeDelta.y >= under)
        {
            rect.sizeDelta = new Vector2(rect.sizeDelta.x, under);
            Invoke("After", 2f);
        }
        //幕閉じ
        else
        {
            rect.sizeDelta += new Vector2(0, 10);
        }
    }

    void After() {
        result.SetActive(true);
        pointsystem.Result();
    }


    public void ReStart()
    {
        //Textを再設定
        cue.text = "Ready?";
        //得点をリセット
        Difficult();
        //時間巻き戻し前に生成にストッパーかける
        prefab = false;
        timer.once = false;
        timer.time = 60;
        //結果モード非表示
        pointsystem.Retry();
        //開始と終了の初期設定
        setup = true;
        setdown = false;
    }

    private void Difficult()
    {
        pointsystem.point = 0;
        GameObject[] thread = GameObject.FindGameObjectsWithTag("Route");
        foreach (GameObject ito in thread)
        {
            Destroy(ito);
            Debug.Log("Rest");
        }
    }
}
