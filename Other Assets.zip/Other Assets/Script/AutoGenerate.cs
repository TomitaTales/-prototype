﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoGenerate : MonoBehaviour {
	///private変数でもInspectorで変更が可能になる
	[SerializeField]
	GameObject[] Prefabs;

	// Use this for initialization
	void Awake () {
		foreach (var prefab in Prefabs) {
			// 特定のGameObjectが無ければ生成
			/// GameObjectを名前だけで探して取得
			if (GameObject.Find(prefab.name) == null) {
				//
				var obj = Instantiate(prefab);
				//Objectの名前は選択したPrefabを代入
				obj.name = prefab.name;
			}
		}
	}
	
}
