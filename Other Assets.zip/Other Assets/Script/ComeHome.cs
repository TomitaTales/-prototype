﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ComeHome : MonoBehaviour
{
    public GameObject spider;
    //
    private float interval = 0;
    private float random = 0;
    //
    public float min;
    public float max;
    //
    Timer timer;
    StageTime stage;

    // Start is called before the first frame update
    void Start()
    {
        //最初のランダム設定
        random = Random.Range(min, max);
        timer = GameObject.Find("Main Camera").GetComponent<Timer>();
        stage = GameObject.Find("Canvas").GetComponent<StageTime>();
    }

    // Update is called once per frame
    void Update()
    {
        //カーテン幕上げで生成開始
        if (stage.prefab)
        {
            //時間切れになったら生成ストップ
            if (timer.time > 0)
            {
                interval += Time.deltaTime;
                if (interval >= random)
                {
                    Instantiate(spider, transform.position, transform.rotation);
                    interval = 0;
                    random = Random.Range(min, max);
                }
            }
        }
    }
}
