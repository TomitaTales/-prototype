﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PointSystem : MonoBehaviour
{
    public int point;
    public Text score;
    //結果表示一式
    public Text title;
    public Text your;
    public Text result;
    //ボタン表示用判定
    public bool push;
    //
    public StageTime stage;


    private void Awake()
    {
        //結果表示一式は非表示
        title.enabled = false;
        your.enabled = false;
        result.enabled = false;
        //ボタンを非表示
        stage.reset.gameObject.SetActive(false);
        stage.quit.gameObject.SetActive(false);
    }


    // Start is called before the first frame update
    void Start()
    {
        point = 0;
        //判定はfalse
        push = false;
    }

    // Update is called once per frame
    void Update()
    {
        score.text = point.ToString();
        result.text = point.ToString();
    }

     public void Result() {
        StartCoroutine("Past");
    }

    IEnumerator Past() {
        yield return new WaitForSeconds(1f);
        title.enabled = true;
        yield return new WaitForSeconds(1f);
        your.enabled = true;
        yield return new WaitForSeconds(1f);
        result.enabled = true;
        yield return new WaitForSeconds(1f);
        push = true;
    }

    public void Retry() {
        //結果表示一式は非表示
        title.enabled = false;
        your.enabled = false;
        result.enabled = false;
        //ボタンを非表示
        stage.reset.gameObject.SetActive(false);
        stage.quit.gameObject.SetActive(false);
        push = false;
        //結果モード非表示
        stage.result.SetActive(false);
    }
}
