﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sample1 : MonoBehaviour
{
    public float speed;
    Rigidbody2D rigidbody2d;
    Animator animator;
    //座標
    Vector2 start;
    Vector2 finish;
    Vector2 different;
    float direction;
    //
    bool once;
    public float past;
    //
    bool enter;
    bool exit;
    
    //他スクリプト参照
    public Sample6 sample;

    // Start is called before the first frame update
    void Start()
    {
        rigidbody2d = GetComponent<Rigidbody2D>();
        animator = GameObject.Find("Spider").GetComponent<Animator>();
        
        once = true;
        enter = false;
        exit = false;
        
    }

    // Update is called once per frame
    void Update()
    {
        //
        transform.position = new Vector3(Mathf.Clamp(transform.position.x, -2, 2), transform.position.y, transform.position.z);
        if (!once) {
            StartCoroutine("PastTime");
        }
    }

    IEnumerator PastTime() {
        yield return new WaitForSeconds(past);
        once = true;
        //Debug.Log("OK");
    }



    private void OnTriggerEnter2D(Collider2D collider2d)
    {
        if (collider2d.tag == "Start")
        {
            //進行方向を取得

            /*
            //sample = collider2d.gameObject.GetComponent<Sample6>();
            sample = GameObject.FindGameObjectWithTag("Route").GetComponent<Sample6>();
            start = sample.Start.transform.position;
            finish = sample.Finish.transform.position;
            different = start - finish;
            float path = Mathf.Atan2(different.x, different.y);
            direction = path * Mathf.Rad2Deg;
            Debug.Log(start);
            Debug.Log(finish);
            */
            GameObject route = collider2d.gameObject.transform.parent.gameObject;
            /// +180°で逆向きに対応
            direction = route.transform.localEulerAngles.z + 180;
            Debug.Log("Start:" + direction);

            //
            enter = true;
        }
        if (collider2d.tag == "Finish")
        {
            //進行方向を取得

            /*
            //sample = collider2d.gameObject.GetComponent<Sample6>();
            ///新しい方を選択してしまう
            sample = GameObject.FindGameObjectWithTag("Route").GetComponent<Sample6>();
            start = sample.Start.transform.position;
            finish = sample.Finish.transform.position;
            different = finish - start;
            float path = Mathf.Atan2(different.x, different.y);
            direction = path * Mathf.Rad2Deg;
            */

            GameObject route = collider2d.gameObject.transform.parent.gameObject;
            direction = route.transform.localEulerAngles.z;
            Debug.Log("Finish:" + direction);

            //
            exit = true;
        }
    }

    private void OnTriggerStay2D(Collider2D collider2d)
    {
        //
        animator.SetBool("Walk", true);
        if (collider2d.tag == "Ground")
        {
            //重力や接触によるエラーを阻止
            ///Constraints:Rigidbodyでの位置や回転の固定を制御する
            rigidbody2d.constraints = RigidbodyConstraints2D.FreezeAll;
            //移動
            transform.Translate(0, speed, 0);
        }


        if (once)
        {
            if (collider2d.tag == "Route")
            {
                //Ground接触時の処理を継承
                rigidbody2d.constraints = RigidbodyConstraints2D.FreezeAll;
                transform.Translate(0, speed, 0);
                //
                //Debug.Log("In");
                transform.localEulerAngles = new Vector3(0, 0, direction);
            }
        }
        if (collider2d.tag == "Start")
        {
            if (exit)
            {
                if (once)
                {
                    transform.localEulerAngles = new Vector3(0, 0, 0);
                    //Debug.Log("Out");
                    once = false;
                    exit = false;
                }
            }
            
        }

        if (collider2d.tag == "Finish")
        {         
            if (enter)
            {
                if (once)
                {
                    transform.localEulerAngles = new Vector3(0, 0, 0);
                    //Debug.Log("Out");
                    once = false;
                    enter = false;
                }
            }
            
        }
    }

    private void OnTriggerExit2D(Collider2D collider2d)
    {
        /*
        if (collider2d.tag == "Ground")
        {
            finish = true;
        }
        if (collider2d.tag == "Route")
        {
            start = true;
        }
*/


        if (collider2d.tag == "Ground" && collider2d.tag == "Route")
        {
            //重力解放
            rigidbody2d.constraints = RigidbodyConstraints2D.None;
            //
            animator.SetBool("Walk", false);
        }
    }


}
