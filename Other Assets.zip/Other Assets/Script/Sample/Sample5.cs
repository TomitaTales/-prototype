﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sample5 : MonoBehaviour
{
    public Vector2 touch_position;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0)) {
            touch_position = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Debug.Log(touch_position);
            //
            RaycastHit2D hit = Physics2D.Raycast(touch_position, Vector2.zero);
            if (hit) {
                Bounds rect = hit.collider.bounds;
                Debug.Log(hit.collider.gameObject.tag);
            }
        }
    }
}
