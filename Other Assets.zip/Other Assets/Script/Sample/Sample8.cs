﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sample8 : MonoBehaviour
{
    //
    GameObject player;
    //取得用Object
    public GameObject spider;
    public GameObject[] over_there;

    /*必要パラメータ*/
    //次Waveまでのターン
    private float interval;
    //出現でランダム値を使用する
    private int random;
    //最大個数
    public float max;

    /*他スクリプト参照*/
    Timer timer;
    StageTime stage;
    Sample10 sample;

    // Start is called before the first frame update
    void Start()
    {
        //ステージ上の蜘蛛を取得する
        player = GameObject.FindGameObjectWithTag("Player");
        //最初のランダム設定
        //stage = GameObject.Find("Canvas").GetComponent<Stage>();
        //各パラメータの設定
        max = 1;
        interval = 0;
    }

    // Update is called once per frame
    void Update()
    {
        //Wave管理
        if (interval > 4) {
            max++;
            interval = 0;
        }

        //実際の生成管理
        //ステージに蜘蛛がいなければ生成。
        if (player == null)
        {
            //生成前に他の蜘蛛の生存を確認
            player = GameObject.FindGameObjectWithTag("Player");
            //いないことが確認できれば生成
            if (player == null)
            {
                //Waveにそって必要個数生成
                for (int i = 0; i < max; i++)
                {
                    ///場所はランダムにして出現
                    random = Random.Range(0, 3);
                    GameObject player2 = Instantiate(spider, over_there[random].transform.position, transform.rotation) as GameObject;
                    ///ダブり防止で、後から生成した蜘蛛は後ろにズラす
                    player2.transform.position = new Vector3(player2.transform.position.x, player2.transform.position.y + (2 * i), player2.transform.position.z);
                }
                //生成を終了して次Waveまでのターンを進める
                player = GameObject.FindGameObjectWithTag("Player");
                interval++;
            }
        }
    }
}
