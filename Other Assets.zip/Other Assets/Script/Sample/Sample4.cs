﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sample4 : MonoBehaviour
{
    //
    public GameObject linePrefab;
    public GameObject foresee;
    //線の長さ
    public float lineLength;
    //線の幅
    public float lineWidth;
    //タッチ判定
    RaycastHit2D hit;
    //各座標
    private Vector3 touchPos;
    public Vector3 startPos;
    public Vector3 endPos;
    //他スクリプト参照
    public Sample6 sample;

    // Start is called before the first frame update
    void Start()
    {
        foresee.gameObject.SetActive (false);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            //タッチした場所の座標を取得
            touchPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            touchPos.z = 0;
            //タッチした場所を確認
            hit = Physics2D.Raycast(touchPos, Vector2.zero);
        }
        if (Input.GetMouseButton(0)) {
            //元線にタッチ出来ていたら実行
            ///RaycastHit2Dで何も取得できなかったらエラーになってしまう
            ///
            if (hit.collider.gameObject.tag == "Ground")
            {
                //最初と最後の地点を設定
                startPos = touchPos;
                endPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                endPos.z = 0;
                //予測線を導入
                foresee.gameObject.SetActive(true);
                foresee.transform.position = (startPos + endPos) / 2;
                foresee.transform.up = (endPos - startPos).normalized;
                //長さを調整
                ///端っこ同士で調整できない(外部で作ったイラストの大きさが反映されていた)
                foresee.transform.localScale = new Vector3(lineWidth, (endPos - startPos).magnitude, lineWidth);
                foresee.transform.parent = this.transform;
            }
        }


        if (Input.GetMouseButtonUp(0))
        {
            //予測線は消える
            foresee.gameObject.SetActive(false);
            //最後にタッチしていた場所を確認
            hit = Physics2D.Raycast(endPos, Vector2.zero);
            //元線にタッチ出来ていたら実行
            if (hit.collider.gameObject.tag == "Ground")
            {
                if ((endPos - startPos).magnitude > lineLength)
                {
                    //実線として確定
                    GameObject obj = Instantiate(linePrefab, transform.position, transform.rotation) as GameObject;
                    //
                    sample = obj.gameObject.GetComponent<Sample6>();
                    sample.Paste();
                    //位置は最初と最後の地点の中間
                    obj.transform.position = (startPos + endPos) / 2;
                    obj.transform.up = (endPos - startPos).normalized;
                    //長さを調整
                    obj.transform.localScale = new Vector3(lineWidth, (endPos - startPos).magnitude, lineWidth);
                    obj.transform.parent = this.transform;
                    touchPos = endPos;
                }
            }
        }

    }
}
