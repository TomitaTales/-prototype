﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sample6 : MonoBehaviour
{   //各座標
    private Vector3 touchPos;
    public GameObject Start;
    public GameObject Finish;
    public GameObject startPrefab;
    public GameObject finishPrefab;
    //他スクリプト参照
    Sample4 sample;

    // Start is called before the first frame update
    void Awake()
    {
        sample = GameObject.FindGameObjectWithTag("Sample").GetComponent<Sample4>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public void Paste() {
        Start = (GameObject)Instantiate(startPrefab, sample.startPos, transform.rotation);
        Finish = (GameObject)Instantiate(finishPrefab, sample.endPos, transform.rotation);
        StartCoroutine("PastTime");
        //Debug.Log(sample.startPos);
        //Debug.Log(sample.endPos);
    }


    IEnumerator PastTime()
    {
        yield return new WaitForSeconds(1f);
        ///ローカルでの位置を取得してから所属
        Start.transform.parent = transform;
        ///原因不明のサイズ変化を修正
        Start.transform.localScale = new Vector3(0.57f, 0.57f, 0.57f);
        ///ローカルでの位置を取得してから所属
        Finish.transform.parent = transform;
        ///原因不明のサイズ変化を修正
        Finish.transform.localScale = new Vector3(0.57f, 0.57f, 0.57f);
    }


}
