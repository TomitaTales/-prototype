﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    //移動速度
    public float speed;
    //
    Rigidbody2D rigidbody2d;
    Animator animator;
    //タイミング
    private bool once;
    public float past;
    //入力判定
    private bool enter;
    private bool exit;
    //方向
    float direction;
    //
    float startPos;
    float goingPos;
    float distance;
    bool awake = true;
    //他スクリプト参照
    PointSystem pointsystem;
    Timer timer;
    //音源
    public AudioClip doropSound;
    private AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {
        //Component参照
        rigidbody2d = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        //他スクリプト参照
        pointsystem = GameObject.Find("Main Camera").GetComponent<PointSystem>();
        timer = GameObject.Find("Main Camera").GetComponent<Timer>();
        //判定準備
        once = true;
        enter = true;
        exit = true;
        //
        audioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        //範囲を限定
        transform.position = new Vector3(Mathf.Clamp(transform.position.x, -2, 2), transform.position.y, transform.position.z);
        if (!once)
        {
            StartCoroutine("PastTime");
        }
        //一定位置より下に行ったら消す
        if (transform.position.y <= -20) {
            Destroy(gameObject);
        }
    }

    IEnumerator PastTime()
    {
        yield return new WaitForSeconds(past);
        once = true;
        //Debug.Log("OK");
    }


    private void OnTriggerEnter2D(Collider2D collider2d)
    {
        //基本アニメーション
        animator.SetBool("Walk", true);
        //始点に触れたら
        if (collider2d.tag == "Start")
        {
            if (enter)
            {
                //進行方向を取得
                GameObject route = collider2d.gameObject.transform.parent.gameObject;
                /// +180°で逆向きに対応
                direction = route.transform.localEulerAngles.z + 180;
                //Debug.Log("Start:" + direction);
                //Startの判定
            }
        }
        //終点に触れたら
        if (collider2d.tag == "Finish")
        {
            if (exit)
            {
                //進行方向を取得
                GameObject route = collider2d.gameObject.transform.parent.gameObject;
                direction = route.transform.localEulerAngles.z;
                //Debug.Log("Finish:" + direction);
                //Goalの判定
            }
        }
        //ゴールに触れたら
        if (collider2d.tag == "Goal") {
            pointsystem.point += 1;
            Destroy(gameObject);
        }
    }

    private void OnTriggerStay2D(Collider2D collider2d)
    {
        //
        Debug.Log("on");
        //通常ルート
        if (collider2d.tag == "Ground")
        {
            //重力や接触によるエラーを阻止
            ///Constraints:Rigidbodyでの位置や回転の固定を制御する
            rigidbody2d.constraints = RigidbodyConstraints2D.FreezeAll;
            //移動
            transform.Translate(0, speed, 0);
        }
        //分岐ルート
        if (once)
        {
            if (collider2d.tag == "Route")
            {
                //Ground接触時の処理を継承
                rigidbody2d.constraints = RigidbodyConstraints2D.FreezeAll;
                transform.Translate(0, speed, 0);
                //進むべき方向へ向ける
                //Debug.Log(direction);
                transform.localEulerAngles = new Vector3(0, 0, direction);
                //
                if (awake) {
                    startPos = transform.position.x;
                    StartCoroutine("PastTime2");
                    awake = false;
                }
                goingPos = transform.position.x;
                Debug.Log(Mathf.Abs(goingPos));
                distance = goingPos - startPos;
                Debug.Log(Mathf.Abs(distance));
                if (Mathf.Abs(distance) >= 2.00f) {
                    transform.localEulerAngles = new Vector3(0, 0, 0);
                    once = false;
                    Debug.Log("Out");
                    enter = true;
                    exit = true;
                    awake = true;
                }
            }
        }
        //始点(終点)に辿り着いたら通常ルートへ
        /*
        if (collider2d.tag == "Start")
        {
            if (exit)
            {
                if (once)
                {
                    transform.localEulerAngles = new Vector3(0, 0, 0);
                    //Debug.Log("Out");
                    once = false;
                    exit = false;
                }
            }

        }
        if (collider2d.tag == "Finish")
        {
            if (enter)
            {
                if (once)
                {
                    transform.localEulerAngles = new Vector3(0, 0, 0);
                    //Debug.Log("Out");
                    once = false;
                    enter = false;
                }
            }

        }
        */
    }

    private void OnTriggerExit2D(Collider2D collider2d)
    {
        ///現在の接触不良の対策
        if (collider2d.tag == "Ground" || collider2d.tag == "Route")
        {
            Debug.Log("NG");
            //重力解放
            rigidbody2d.constraints = RigidbodyConstraints2D.None;
            //歩き終える・・・
            animator.SetBool("Walk", false);
            audioSource.clip = doropSound;
            audioSource.Play();
        }

    }

    IEnumerator PastTime2() {
        yield return new WaitForSeconds(1f);
        enter = false;
        exit = false;
    }


}
