﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour {
	//表示Text
	public Text watch;
	//時間
	public float time;
	//終了時Animator
	//public Animator finish_anim;
	//終了時表示Panel
	//public GameObject panel;
	//public GameObject panelset;
	//可動設定
	public bool once;
	//音楽ファイル
	//public AudioClip stop_sound;
	//private AudioSource audiosource;
	//他スクリプト参照
	//public Player player;
	//public Judge judge;

	// Use this for initialization
	void Start () {
        /*
		//Panelの表示はOFF
		panel.SetActive (false);
		panelset.SetActive (false);
		//音源の取得
		audiosource = GetComponent<AudioSource>();
        */
        once = false;
    }

    // Update is called once per frame
    void Update () {
        //終了したら時間を停止して終了時処理を実行
        if (once) {
            if (time < 0)
            {
                time = 0;
                /*
                player.able = false;
                finish_anim.SetTrigger ("Finish");
                if (once) {
                    audiosource.clip = stop_sound;
                    audiosource.Play ();
                    once = false;
                }
                StartCoroutine ("Interval");
                */
                //時間をカウントダウン
            }
            else
            {
                time -= Time.deltaTime;
            }
        }
        //残り時間を表示
        watch.text = ((int)time).ToString ();
	}

	
    /*
    
    // Work in parallel for system
	IEnumerator Interval(){
		//それぞれのタイミングで表示
		yield return new WaitForSeconds (3f);
		panel.SetActive (true);
		yield return new WaitForSeconds (0.5f);
		panelset.SetActive (true);
		//シーンリセットを可能にする
		//judge.able = true;
	}

    */
}
